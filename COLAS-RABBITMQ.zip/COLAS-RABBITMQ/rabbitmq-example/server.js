const express = require('express');
const bodyParser = require('body-parser');
const amqp = require('amqplib');

const app = express();
const port = 3000;

// Middleware para parsear JSON
app.use(bodyParser.json());

async function sendMessageToQueue(message) {
  try {
    // Conectar a RabbitMQ
    const connection = await amqp.connect('amqp://localhost');
    const channel = await connection.createChannel();

    const queue = 'task_queue';
   

    // Asegurarse de que la cola existe
    await channel.assertQueue(queue, { durable: true });

    // Enviar el mensaje a la cola
    channel.sendToQueue(queue, Buffer.from(message), { persistent: true });
    console.log(`[x] Mensaje enviado: ${message}`);

    // Cerrar la conexión después de un tiempo
    setTimeout(() => {
      channel.close();
      connection.close();
    }, 500);
  } catch (error) {
    console.error('Error enviando mensaje', error);
  }
}


// Crear endpoint para enviar mensajes a RabbitMQ
app.post('/send', async (req, res) => {
  const { message } = req.body;

  const mensaje = JSON.stringify(req.body)
  console.log("mensaje", mensaje)

  // if (!message) {
  //   return res.status(400).send({ error: 'El mensaje es obligatorio' });
  // }

  await sendMessageToQueue(mensaje);
  // res.send({ status: 'Mensaje enviado a RabbitMQ', mensaje });
  res.status(200).send();
});


// Iniciar el servidor
app.listen(port, () => {
  console.log(`Servidor escuchando en http://localhost:${port}`);
});
