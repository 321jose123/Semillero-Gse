const amqp = require('amqplib');

async function receiveMessages() {
  try {
    // Conectar a RabbitMQ
    const connection = await amqp.connect('amqp://localhost');
    const channel = await connection.createChannel();

    const queue = 'task_queue';

    // Asegurarse de que la cola existe
    await channel.assertQueue(queue, { durable: true });

    console.log(`[*] Esperando mensajes en ${queue}. asi que relajate`);

    // Consumir mensajes de la cola
    channel.consume(queue, (msg) => {
      if (msg !== null) {
        console.log(`[x] Recibido: ${msg.content.toString()}`);
        // Confirmar que el mensaje ha sido procesado
        channel.ack(msg);
      }
    }, { noAck: false });
  } catch (error) {
    console.error('Error recibiendo mensaje', error);
  }
}

receiveMessages();
