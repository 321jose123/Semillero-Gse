const axios = require('axios');

const enviarTarea = async (tarea) => {
  try {
    const response = await axios.post('http://localhost:3000/api/tareas', { tarea });
    console.log(response.data);
  } catch (error) {
    console.error('Error al enviar tarea:', error.message);
  }
};

// Enviar algunas tareas como ejemplo
enviarTarea('Tarea 1');
enviarTarea('Tarea 2');
enviarTarea('Tarea 3');
