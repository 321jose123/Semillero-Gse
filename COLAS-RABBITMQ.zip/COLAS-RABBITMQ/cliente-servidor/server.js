import express from 'express';
import Queue from 'queue'; 
import path from 'path';

const app = express();
const PORT = 3000;

// Crear una cola con Queue
const q = new Queue({
  concurrency: 1, // Limitar a una tarea procesada a la vez
  autostart: true 
});

//cuerpo de las peticiones
app.use(express.json());
app.use(express.static('public'));

// Estado de la cola
let isProcessing = false;

// Endpoint para recibir peticiones
app.post('/api/tareas', async (req, res) => {
  const { tarea } = req.body;

  // Añadir tarea a la cola
  q.push(async (cb) => {
    console.log(`Procesando tarea: ${tarea}`);
    
    
    await new Promise(resolve => setTimeout(resolve, 200)); // Simula procesamiento
    console.log(`Tarea completada: ${tarea}`);

    // Esperar 10 segundos antes de procesar la siguiente tarea
    await new Promise(resolve => setTimeout(resolve, 10000)); // Espera de 10 segundos
    
    cb(); // Indicar que la tarea ha sido completada

    const remainingJobs = queue.length; // Verificar cuántas tareas quedan
    if (remainingJobs > 0) {
      console.log(`Siguiente tarea en cola: ${remainingJobs}`);
    } else {
      isProcessing = false; // No hay más tareas en cola
      console.log('No hay más tareas en cola.');
    }
  });

  // Mensaje inicial para la primera tarea
  if (!isProcessing) {
    isProcessing = true;
    console.log(`Tarea en proceso: ${tarea}`);
    res.json({ mensaje: `Tarea añadida a la cola y actualmente procesando: ${tarea}` });
  } else {
    res.json({ mensaje: `Tarea añadida a la cola. Actualmente hay tareas en proceso.` });
  }
});

// Iniciar el servidor
app.listen(PORT, () => {
  console.log(`Servidor corriendo en http://localhost:${PORT}`);
});
